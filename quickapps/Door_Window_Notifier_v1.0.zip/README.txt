-------------------------------------------------------------------------------
WINDOW/DOOR NOTIFICATION QUICK APP
Version 1.0.0 (January 2026) – Initial release
Copyright (c) 2026 Joep Verhaeg <info@joepverhaeg.nl>
Licensed under the MIT License. See LICENSE file for details.
-------------------------------------------------------------------------------
NOTE FOR INSTALLERS:
Using this QuickApp commercially without supporting its development
is strongly discouraged. If you deploy this for clients,
a donation is expected to keep this project sustainable.
https://docs.joepverhaeg.nl/donate
-------------------------------------------------------------------------------
DOCUMENTATION:
Installation and usage instructions can be found at:
https://docs.joepverhaeg.nl/hc3-door-window-sensor/
-------------------------------------------------------------------------------
